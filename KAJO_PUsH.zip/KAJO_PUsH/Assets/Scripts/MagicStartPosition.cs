using System;
using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using Unity.VisualScripting;
using UnityEngine;


public class MagicStartPosition : MonoBehaviour
{
    [SerializeField] GameObject MagicBall;
    [SerializeField] Transform ballPositon;
    [SerializeField] float MagicLifeCycle = 4f;
    // kyseinen objekti ja sen Vector koordinaatit + kierre.
    void Update()
    {
      MagicLocation();
    }
    

    void MagicLocation() 
    {
      
      if (Input.GetMouseButtonDown(1)) 
      {
        GameObject magicBall = Instantiate(MagicBall,ballPositon.position, ballPositon.rotation);
        Destroy(magicBall, MagicLifeCycle) ;
        // tässä lisäämme vielä "instantiaten" eli käskyn jopa koskee vain "Klooneja" koska sijoitamme sen omaksi GameObjectiksi. 
        // eli jättää alkuperäisen GameObjectin rauhaan ilman että tuhoaa sitä
        // tämä takaa alku peräisen toimivuuden ajastimen ulkopuolella
        Debug.Log("MagicLocator");
      }
    }

}
