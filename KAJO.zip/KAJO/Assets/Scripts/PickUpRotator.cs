using UnityEngine;

public class PickUpRotator : MonoBehaviour
{
    void Update()
    {
        transform.Rotate(0, 1, 0); //pickUpille liikettä
    }
}
