using UnityEngine;
using UnityEngine.Pool;

public class PlayerStateList : MonoBehaviour
{
    public bool jumping = false;
    public bool dashing = false;
}
